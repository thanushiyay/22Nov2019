import { Component, OnInit } from '@angular/core';
import { SetTitleService } from '../set-title.service';
declare var $: any;
@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  
  constructor(private _setTitleService:SetTitleService) { }

  ngOnInit() {
    $('button').click(function(){
      alert('Wass up!');
       });
       this._setTitleService.checkPageTitle();
  }

}
