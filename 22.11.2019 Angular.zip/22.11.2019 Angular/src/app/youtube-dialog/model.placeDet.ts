export interface Dett
{
    
    
        name:String,
        image:String,
        content:String,
        embed:String,
        rating:number,
        est_hrs:number
    
}