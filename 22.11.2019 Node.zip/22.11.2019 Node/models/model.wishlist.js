const mongoose=require('mongoose');
const wishlistSchema=new mongoose.Schema({

        email:{
            type:String,
            required:true
        },
        saved_details:[
            {
        date:{
            type:String,
            required:true
        },
        det:
        [
            {
                type:String,
                required:true
            }
        ],
        visiting_place:
        {
            type:String,
            required:true
        },
        seeing_type:
        {
            type:String,
            required:true
        }
    }
    ]
});
const Wishlist=mongoose.model('Wishlist',wishlistSchema);
module.exports=Wishlist;