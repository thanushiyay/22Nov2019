import { Component, OnInit } from '@angular/core';
import { SetTitleService } from '../set-title.service';

@Component({
  selector: 'app-careers',
  templateUrl: './careers.component.html',
  styleUrls: ['./careers.component.css']
})
export class CareersComponent implements OnInit {

  constructor(private _setTitleService:SetTitleService) { }

  ngOnInit() {

    this._setTitleService.checkPageTitle();
  }

}
