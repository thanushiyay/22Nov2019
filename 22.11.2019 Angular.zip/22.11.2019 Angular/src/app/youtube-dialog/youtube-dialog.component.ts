import { Component, Renderer2,OnInit } from '@angular/core';
import {MatDialog, MatDialogRef} from '@angular/material';
import { MainDialogComponent } from '../main-dialog/main-dialog.component';
import { MainServiceService } from '../main-service.service';
import     {Dett}   from './model.placeDet';
// import { interval } from 'rxjs';
import {DomSanitizer} from  '@angular/platform-browser';
import { validateBasis } from '@angular/flex-layout';
// import { OwlOptions } from 'ngx-owl-carousel-o';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { PopUpDialogComponent } from '../pop-up-dialog/pop-up-dialog.component';
import {ActivatedRoute,Router, Route} from '@angular/router';
import { TripDialogComponent } from '../trip-dialog/trip-dialog.component';
import { IgxCardThumbnailDirective } from 'igniteui-angular';
import {Title} from '@angular/platform-browser';
import { SetTitleService } from '../set-title.service';
import {HttpClient, HttpClientModule}  from '@angular/common/http';
import * as _ from 'lodash'
import { DialogComponent } from '../dialog/dialog.component';
import { Dett1 } from './model.placeDet2';
// import { DatePipe } from '@angular/common';
import { dateFormat } from 'dateformat';
import { DatePipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';
// var _ =require('lodash');
@Component({
  selector: 'app-youtube-dialog',
  templateUrl: './youtube-dialog.component.html',
  styleUrls: ['./youtube-dialog.component.css']
})

export class YoutubeDialogComponent implements OnInit {
  place: string;
  seeing_place: string;
  // places_details:string[];
  ticked=false;
 
  check_circle="fa fa-check-circle";
  public places_title=['With Kids','Museums and Culture','Sight Seeing','Gastronomy','Night Life and Shopping'];
  
  
  todayString  = new Date();
  
  customOptions: OwlOptions = {
    loop: true,
    mouseDrag: false,
    touchDrag: false,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: ['<h5 class="fa fa-angle-left"></h5>', '<h5 class="fa fa-angle-right"></h5>'],
    responsive: {
      0: {
        items: 1
      },
      50: {
        items: 2
      },
       100: {
         items: 3
       },
       150: {
         items: 4
       },
      200: {
        items: 5
       },
       250: {
         items: 6
       }
      
    
    },
    nav: true
  }
  // detailPlace:any;
  addArray:string[]=[];
  est_hrs:number;
  det_name:string
  activeClass=false;
  youtube_value: any;
  your_value: string;
  _your_value: string;
  popUpDialog: string;
  hrs: number;
  title:string;

  d:Array<Dett1>=[];
  details:Dett;
  // Object d:dett
  data: string;

// d:any[];
   tdayDate;
  constructor(public dialogRef:MatDialogRef<YoutubeDialogComponent>,public dialog:MatDialog,
    public _mainService:MainServiceService,private sanitizer:DomSanitizer,
    private router:Router,private route:ActivatedRoute,private _titleService:Title,
    private _setTitleService:SetTitleService,private http:HttpClient,
    private datePipe:DatePipe) {
      this.tdayDate = this.datePipe.transform( new Date(),'MMM dd, yyyy,  h:mm:ss a');
      
     }
  
  ngOnInit() {

    this.place=this._mainService.getOption();//antartica
    this.seeing_place=this._mainService.getSeeing_place();//with kids
    alert("seeing_placesee"+this.seeing_place);
    this.youtube_value=this.sanitizer.bypassSecurityTrustResourceUrl('https://www.youtube.com/embed/6wD4V0rvlDI');
    this.est_hrs=0;
    this._setTitleService.checkPageTitle();
    const data='thanushiya';
    // this.http.post('/api/v1/places_details/',data).subscribe((data:any)=>{
    //        console.log(data);
    // });



    
    this.http.get('/api/v1/place_details/' + this.place).subscribe((data:any)=>
    {
          
            alert("places name" +data.place_name);
            let p:[];
            p=data["place_details"];
            _.forEach(p,val=>{
            
              this.d.push(val);
            });
            console.log(this.d);
            console.log("d log:"  + this.d[2]);
            _.forEach(this.d,v1 => {
                 console.log(v1["title"]);
              
            });
            alert(this.d.length);
    });
  }
  dialogBack()
  {
     this.dialogRef.close();
     this.dialog.open(MainDialogComponent,{disableClose:true});
     this.router.navigate(['plan-trip',this._mainService.getOption(),'choose-travel-kind'],{relativeTo:this.route});
     setTimeout(()=>
     {
              this._setTitleService.checkPageTitle();
     },5);
     alert(this.d.length);
    }
  dialogClose()
  {
    this.dialogRef.close();
    this.dialog.afterAllClosed.subscribe(result=>
      {
         this.router.navigate(['../'],{relativeTo:this.route});    
         setTimeout(()=>
         {
           // console.log("This is home page:" +this.router.url);
                  this._setTitleService.checkPageTitle();
         },5);
      });
  
      
  }
  playPlayer(value:string)
  {
     console.log(value);
     this.youtube_value=this.sanitizer.bypassSecurityTrustResourceUrl(value);
  }
   activeCall()
   {
       this.activeClass=true;
      
   }
   isTicked(det_name:string)
   {

    for(let x of this.d)
    {
       for(let y of x.details)
       {
         if(y.name==det_name)
         {
            this.hrs=y.est_hrs;
            
         }
       }
    }
        if(this.addArray.includes(det_name))
        {
          const index: number = this.addArray.indexOf(det_name);
          this.addArray.splice(index,1);
          console.log(this.addArray);
          console.log("removed");
          this.est_hrs=this.est_hrs-this.hrs;
        }
        else
        {
          this.addArray.push(det_name);
            this.est_hrs=this.est_hrs+this.hrs;
          console.log("added");
         
        }
       
   }
   checkTicked(det_name:string)
   {
         if(this.addArray.includes(det_name))
         {
            this.ticked=true;
            // console.log("hiiii");
            return true;
         }
         else
         {
           return false;
         }
        //  console.log("chintuu");
         
   }
   isArrayHaving()
   {
      // const  greyColor:HTMLElement=document.getElementById('hr_style');
      if(this.addArray.length>0)
      {
        return true;
      }
      else
      {
        return false;
      }
   }
   pTagShow=false;
  changeIconChecked()
  {
    // this.check_circle="fa fa-times-circle";
   return true;
  }
  changeIconRemoved()
  {
    // this.check_circle="fa fa-check-circle";
   return false;
  }
  removeLastElement()
  {
    console.log("chintuuuuu!!!!!!!!");
    this.addArray.splice(-1,1);
  }
  days:number;
  openTripDialog()
  {
    console.log(this._mainService.isSigned);
      if(!this._mainService.isSigned)
      {
              alert("Please signin");
              this.dialog.open(DialogComponent);
      }
      else if(this._mainService.isSigned)
      {
        // console.log( {{this.todayString | Date}});
        console.log(this.addArray);
        console.log(this.tdayDate);
        var  data={ email: this._mainService.getMail(),
          det:this.addArray,
          date:this.tdayDate,
          visiting_place:this.place,
          seeing_type:this.seeing_place,
         }
        this.http.post('/api/v1/wishlist/',data).subscribe((data:any)=>
        {
               alert("successfullly  stored");
        });
        this.dialog.open(TripDialogComponent,{disableClose:true});
        // this.dialogRef.close({data:'data'});
        this.router.navigate(['plan-trip',this._mainService.getOption(),'trip-information'],{relativeTo:this.route});
        this._mainService.setLength(this.addArray.length);
        // console.log(this.addArray.length);
        if(this.est_hrs>10)
        {
         this.days=Math.round(this.est_hrs/10);
        }
        else
        {
          this.days=1;
        }
        this._mainService.setEstimatedDays(this.days);
        
}
  }
}
