import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { auth } from 'firebase';
import {AngularFirestore} from '@angular/fire/firestore';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { MatDialog } from '@angular/material';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
 
  
  private eventAuthError=new BehaviorSubject<string>("");
  eventAuthError$ =this.eventAuthError.asObservable();
 
  // user:firebase.User;
  newUser:any;
  userCredential: any;
  constructor(private afAuth:AngularFireAuth,private db:AngularFirestore,private router:Router,private dialog:MatDialog) { }
  

  createUser(user) {
    // console.log(user.email)
    let data=user.value;
     this.afAuth.auth.createUserWithEmailAndPassword(user.email,user.password)
              .then(userCredential =>
                {
                  this.newUser=user;
                  console.log(userCredential);
                  userCredential.user.updateProfile({
                    displayName: user.firstName
                  });
                  // console.log(this.userCredential.user.uid);
                  this.insertUserData(userCredential)
                  .then(() =>
                  {
                    this.dialog.closeAll();
                    this.router.navigate(['/about']);
                  });
                }).catch(error =>
                  {
                      this.eventAuthError.next(error);
                      
                  })
                
  }
  insertUserData(userCredential: auth.UserCredential) {

    return this.db.collection('users').doc("0u33RYf82wQjfGGcMuIABJEBThh2").set({
            email:this.newUser.email,
            firstName:this.newUser.firstName,
            lastName:this.newUser.lastName,
            password:this.newUser.password
          }
        )
  }
  // insertUserData(userCredential:firebase.auth.UserCredential)
  // {
  //   //   console.log(this.userCredential.user.uid);
  //   return this.db.doc(`Users/${userCredential.user.}`).set({
      
  //       email:this.newUser.email,
  //       firstName:this.newUser.firstName,
  //       lastName:this.newUser.lastName,
  //       password:this.newUser.password
      
  //     }
  //   )
  // }

  loginGoogle() {
    this.afAuth.auth.signInWithRedirect(new auth.GoogleAuthProvider);
  }
  logout() {
      this.afAuth.auth.signOut();
  }
}
