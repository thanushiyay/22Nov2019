var mongoose=require('mongoose');
var express=require('express');
const _=require('lodash');
const Places_list=require('../models/model.places_list');
var router = express.Router();
const Places_diff_views=require('../models/model.places_diff_views');


router.post('/',async(req,res,next)=>
{
    // const data = req.body;
        try
        {
            const places=new Places_list({name:['Asia','Africa','Antartica','Kerala','Tamilnadu','Asia','Africa','Antartica','Kerala',
            'Tamilnadu','Asia','Africa','Antartica','Kerala','Tamilnadu']});
            const places_diff_views=new Places_diff_views({
                name:['With Kids','Museums and Culture','Sight Seeing','Gastronomy','Night Life and Shopping']
            });
            places.save();
            places_diff_views.save();
        //     console.log(places);
        //     console.log(places_diff_views);
        }
        catch(err)
        {

        } 
        res.status(200);
});
router.get('/',async(req,res,next)=>
{
        
        Places_list.find({name:{$exists:true}},function(err,places_list)
        {
               
                const placess=new Places_list({
                        name:places_list[0].name
                });
                // console.log(placess);
                return res.json(placess);
        });
      
      
});



module.exports = router;




            // Places_list.find({name:'Thanu'},function(err,places_list)
            //  {
            //     // let places=new Places_list({name:[places_list]});
            //     // let places=new Places_list({name:[places_list.name]});
            //     console.log(places_list.length);
            //      for(var i=0;i<places_list.length;i++)
            //      {
            //          console.log(places_list[i].name[0]);
            //      }
               
            //  });