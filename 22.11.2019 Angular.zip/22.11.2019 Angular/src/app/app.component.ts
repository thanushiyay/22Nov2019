import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { SetTitleService } from './set-title.service';
import { MainServiceService } from './main-service.service';
import { LoginService } from './login.service';
import { DialogComponent } from './dialog/dialog.component';
import { MatDialog } from '@angular/material';
import { MainDialogComponent } from './main-dialog/main-dialog.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit{
  // router: any;
  // opened=false;
  title="Plan Trips with Videos - SeeVoov";
  user=false;
  urlString: any[];
  user1: string;
  isSigned: any;
  printOption:string;
  selectedOption:string;
  selected:string;
  showHide=true;
  change_style_css:string;
  change_search_icon:string;
  opened=false;
  HideShow=false;
  HideClass:string;
  middle_hide=true;
  spinning_show=false;
  hideDrop:string;
  close=false;
  visiting_place:string;
  routing_val:string;
  appHome: boolean;
  constructor(private router:Router,public dialog:MatDialog,private _setTitleService:SetTitleService,
    public _mainService:MainServiceService,
    public _loginService:LoginService,private route:ActivatedRoute,
    private _titleService:Title){}
         ngOnInit()
         {
           
          this.change_style_css='search_input';
          this.change_search_icon='search_input_i';
          
          this._mainService.change.subscribe(isSigned => {
            this.isSigned = isSigned;
            console.log(this._mainService.isSigned);
            if (this._mainService.isSigned) {
              this.user1 = this._mainService.getUser();
              console.log("user1"+this.user1);
              this.user = true;
              console.log("user"+this.user);
            }
          });
             setTimeout(()=>
             {
              this.router.navigate(['home']);
              setTimeout(()=>
              {
                this.routing_val=this._setTitleService.checkPageTitle();
                
              },3);
            
             },1);
             this.hideDrop='dropdown-content';
    
     
             this._mainService.open.subscribe((data)=>
             {
                 this.opened=data;
             });
            
            //  alert(this.routing_val);
         }
         
  openDialog()
  {
  
    this.dialog.open(DialogComponent,{disableClose:true});
  }
 
  change_style()
  {
    this.HideShow=true;
      this.showHide=false;
      this.change_style_css='toggle_style';
      this.change_search_icon='search_input_i2';
      this.HideClass='float_label';
    
    
  }
  checkPageTitles()
  {
    this.routing_val=this._setTitleService.checkPageTitle();
   
  }
  closing_opened()
  {
       this.opened=false;
       this.HideShow=false;
       this.showHide=true;
       this.change_style_css="search_input";
       this.change_search_icon='search_input_i';
       this.router.navigate(['../../../']);
 
  }
  loading_module()
  {
    this.printOption=this.selectedOption;
    this._mainService.setOption(this.selectedOption);
    this.middle_hide=false;
    this.spinning_show=true;
    setTimeout(()=>
    {
      this.spinning_show=false;
       this.dialog.open(MainDialogComponent,{ disableClose: true });
       this.middle_hide=true;
    },5);
    this.visiting_place=this._mainService.getOption();
    this.router.navigate(['plan-trip',this.visiting_place,'choose-travel-kind'],{relativeTo:this.route});
    setTimeout(()=>
    {
        this.HideShow=false;
        this.showHide=true;
        this.change_style_css="search_input";
       this.change_search_icon='search_input_i';
       this.HideClass="";
    },20);
  }

  showDropdown()
  {
    this.close=false;
     this.hideDrop='dropdown-content_block';
    
  }

   showProfile()
   {

   }
  hideDropdown()
  {
    this.close=true;
    this.hideDrop='dropdown-content';
  }
  logout()
  {
    this._mainService.logout();
    this.user = false;
    
}
}
