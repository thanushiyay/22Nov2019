const mongoose = require('mongoose');
var express = require('express');
const Wishlist = require('../models/model.wishlist');
const router = express.Router();
const _ = require('lodash');
const WishlistService = require('../services/service.wishlist');

router.post('/', async (req, res, next) => {



	const body = req.body;
	try {
		try {
			const updated_status = await WishlistService.checkForSaved(body);
			// console.log(updated_status);
			if (!updated_status) {
				const create_status = WishlistService.create(body);
				console.log("Created status" + create_status);
			}
		}
		catch (err) {
			return res.status(400).send({ message: "Errror" });
		}







		console.log("In the wishlist");
	}
	catch (err) {


		// unexpected error	
		return next(err);
	}

});


module.exports = router;