import { Component, OnInit } from '@angular/core';
import {MatDialog,MatDialogRef} from '@angular/material';
import { TermsDialogComponent } from '../terms-dialog/terms-dialog.component';
import { CreateDialogComponent } from '../create-dialog/create-dialog.component';
import { AngularFireAuth } from '@angular/fire/auth';
import { LoginService } from '../login.service';
import { SigninDialogComponent } from '../signin-dialog/signin-dialog.component';

@Component({ 
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent implements OnInit {

  constructor(public dialog:MatDialog,private afAuth:AngularFireAuth,private _loginService:LoginService,
    private dialogRef:MatDialogRef<DialogComponent>) { }

  ngOnInit() {
  }
  termsDialog()
  {
    this.dialog.open(TermsDialogComponent,{disableClose:true});
  }
  CreateDialog()
  {
    this.dialogRef.close();
    this.dialog.open(CreateDialogComponent,{disableClose:true});
    
  }
  loginWithGoogle()
  {
       this._loginService.loginGoogle();
  }
  openSigninDialog()
  {
     this.dialogRef.close();
     this.dialog.open(SigninDialogComponent,{disableClose:true});
  }

}
