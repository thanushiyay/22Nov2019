import { Component, OnInit } from '@angular/core';
import { SetTitleService } from '../set-title.service';
//import { IgxCalendarComponent } from 'igniteui-angular';
@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
  // @ViewChild('calendar', { read: IgxCalendarComponent }) public calendar: IgxCalendarComponent;
  constructor(private _setTitleService:SetTitleService) { }
  //@ViewChild('calendar', { read: IgxCalendarComponent }) public calendar: IgxCalendarComponent;
  ngOnInit() {
      this._setTitleService.checkPageTitle();
  }

}
