import {Dett} from './model.placeDet';
export interface Dett1
{
    title:string,
    details:Array<Dett>;

}