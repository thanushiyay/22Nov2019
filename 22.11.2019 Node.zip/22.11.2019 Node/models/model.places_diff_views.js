const mongoose=require('mongoose');
const  places_diff_views=new mongoose.Schema(
    {
        name:[String]
    }
);
const Places_diff_views=mongoose.model('Places_diff_views',places_diff_views);
module.exports=Places_diff_views;