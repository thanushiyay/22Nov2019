const mongoose=require('mongoose');
var express = require('express');
const Place_details=require('../models/model.place_details');
const router=express.Router();



router.post('/',async(req,res,next)=>
{
         try
         {
                const data=req.body;
             
            const placeDetails=new  Place_details({
                place_name:'Africa',
                place_details:
                [
                    {'title':'With kids',
                      'details':
                       [
                         {
                           'name':'wth-kids1','image':"../assets/images/details_image/dom.jpg",'content':'This is an amazing place',
                           'embed':'https://www.youtube.com/embed/kpK03Ix1qEo','rating':4,'est_hrs':2
                         },
                         {
                           'name':'with-kids2','image':"../assets/images/details_image/dom.jpg",'content':'A beautiful place',
                           'embed':"https://www.youtube.com/embed/ogyEz71cnuA",'rating':4,'est_hrs':2
                         }
                       ]
                      },
                      {'title':'Museums and Culture',
                      'details':
                       [
                         {
                           'name':'Museums and Culture1','image':"../assets/images/details_image/dom.jpg",'content':'Museums Content',
                           'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':2
                         },
                         {
                           'name':'Museums and Culture2','image':"../assets/images/details_image/dom.jpg",'content':'Museums Contetn2',
                           'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':2
                         }
                       ]
                      },
                      {'title':'Sight Seeing',
                      'details':
                       [
                         {
                           'name':'Sight Seeing1','image':"../assets/images/details_image/dom.jpg",'content':'See the sight SeeingSee the second sight seeing See the second sight seeing SeeingSee the second sight seeing Seeing',
                           'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':2
                         },
                         {
                           'name':'Sight Seeing2','image':"../assets/images/bg_image.jpg",'content':'See the second sight seeing See the second sight seeing SeeingSee the second sight seeing Seeing',
                           'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':3
                         },
                         {
                          'name':'Sight Seeing3','image':"../assets/images/details_image/dom.jpg",'content':'See the sight SeeingSee the second sight seeing See the second sight seeing SeeingSee the second sight seeing Seeing',
                          'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':2
                        },
                        {
                          'name':'Sight Seeing4','image':"../assets/images/details_image/dom.jpg",'content':'See the sight SeeingSee the second sight seeing See the second sight seeing SeeingSee the second sight seeing Seeing',
                          'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':4
                        },
                        {
                          'name':'Sight Seeing5','image':"../assets/images/details_image/dom.jpg",'content':'See the sight SeeingSee the second sight seeing See the second sight seeing SeeingSee the second sight seeing Seeing',
                          'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':3
                        },
                        {
                          'name':'Sight Seeing6','image':"../assets/images/details_image/dom.jpg",'content':'See the sight SeeingSee the second sight seeing See the second sight seeing SeeingSee the second sight seeing Seeing',
                          'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':5
                        },
                       ]
                      },
                      {'title':'Gastronomy',
                      'details':
                       [
                         {
                           'name':'Gastronomy1','image':"../assets/images/details_image/dom.jpg",'content':'See the sight Seeing',
                           'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':2
                         },
                         {
                           'name':'Gastronomy2','image':"../assets/images/details_image/dom.jpg",'content':'See the sight Seeing',
                           'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':2
                         }
                       ]
                      },
                      {'title':'Night Life and Shopping',
                      'details':
                       [
                         {
                           'name':'Night Life and Shopping1','image':"../assets/images/details_image/dom.jpg",'content':'See the sight Seeing',
                           'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':2
                         },
                         {
                           'name':'Night Life and Shopping2','image':"../assets/images/details_image/dom.jpg",'content':'See the sight Seeing',
                           'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':2
                         }
                       ]
                      }
            ]
            
         });
         placeDetails.save();
          return res.status(200).json(placeDetails);
        }
     
         catch(err)
         {

         }
});




router.get('/:place',async(req,res,next)=>
{
         try
         {
               Place_details.find({place_name:req.params.place},function(err,placeDetail)
               {
                     
                        const details=new Place_details({
                            place_name:placeDetail[0].place_name,
                            place_details:placeDetail[0].place_details
                        });
                      
                        
                        return res.status(200).json(details);
               });
              
         }
         catch(err)
         {
               return res.status(400).send("Just error");
         }

});


module.exports=router;