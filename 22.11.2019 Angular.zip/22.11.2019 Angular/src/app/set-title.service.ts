import { Injectable } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { MainServiceService } from './main-service.service';
import { MatDialog } from '@angular/material';
import { MainDialogComponent } from './main-dialog/main-dialog.component';
import { YoutubeDialogComponent } from './youtube-dialog/youtube-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class SetTitleService {
  appName: string;
  present_title: any[];
  urlString: any[];
  constructor(private router: Router, private activatedRoute: ActivatedRoute, private _titleService: Title,
    private _mainService: MainServiceService, private dialog: MatDialog) { }
  checkPageTitle() {
    this.urlString = this.router.url.split('/');
    console.log(this.router.url);
    let urlLength = this.urlString.length;
    if (this.urlString[urlLength - 1] === 'user') {
      this._titleService.setTitle("User Profile");


    }
    if (this.urlString[urlLength - 1] === 'home') {
      this._titleService.setTitle("Plan Trips With Videos - SeeVoov");
      this.appName = 'app-home';
    }
    else if (this.urlString[urlLength - 1] === 'about') {
      this._titleService.setTitle("SeeVoov-About");
      //   this.dialog.open(MainDialogComponent);
      this.appName = 'app-about';

    } else if (this.urlString[urlLength - 1] === 'careers') {
      this._titleService.setTitle("SeeVoov-Careers");
      //   this.dialog.open(MainDialogComponent);
      this.appName = 'app-careers';
    }
    else if (this.urlString[urlLength - 1] === 'affiliates') {
      this._titleService.setTitle("SeeVoov-Affiliates");
      //   this.dialog.open(MainDialogComponent);
      this.appName = 'app-affiliates';
    }
    else if (this.urlString[urlLength - 1] === 'contact') {
      this._titleService.setTitle("SeeVoov-Contact");
      //   this.dialog.open(MainDialogComponent);
      this.appName = 'app-contact';

    }
    else if (this.urlString[urlLength - 1] === 'terms') {
      this._titleService.setTitle("SeeVoov-Terms");
      //   this.dialog.open(MainDialogComponent);
      this.appName = 'app-terms';

    }
    else if (this.urlString[urlLength - 1] === 'choose-travel-kind') {
      this._titleService.setTitle("Plan your trip to " + this._mainService.getOption() + " - SeeVoov");
      //   this.dialog.open(MainDialogComponent);
      this.appName = 'app-home';
    }
    else if (this.urlString[urlLength - 1] === 'where-to-go') {
      this._titleService.setTitle(this._mainService.getOption() + " Attractions - SeeVoov");
      //   this.dialog.open(YoutubeDialogComponent);
      this.appName = 'app-home';
    }
    else if (this.urlString[urlLength - 1] === 'trip-information') {
      this._titleService.setTitle("Trip Information - SeeVoov");
      //   this.dialog
      this.appName = 'app-home';
    }

    return this.appName;
  }
}
