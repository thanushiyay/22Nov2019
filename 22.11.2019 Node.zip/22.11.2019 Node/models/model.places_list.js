const mongoose=require('mongoose');
const places_listSchema = new mongoose.Schema({
	name: [
        String
    ]
});
const Places_list = mongoose.model('Places_list', places_listSchema);
module.exports =Places_list;