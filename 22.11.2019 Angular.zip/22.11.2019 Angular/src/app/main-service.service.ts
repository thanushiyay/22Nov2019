import { Injectable, EventEmitter, Output } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MainServiceService {
  
 
 
  
  public data:string;
  public seeing_place:string;
  youtube_value: any;
  arr_length: number;
  est_days: number;
  firstName: string;
  isSigned=false;
  email: string;
 
  isOpened=false;

  
  constructor() { }

  @Output() change: EventEmitter<boolean> = new EventEmitter();
  @Output() open: EventEmitter<boolean> = new EventEmitter();
  setOption(val)
  {
    // debugger;
    this.data=val;
  }
  getOption()
  {
    return this.data;
  }
  setSeeing_place(seeing_place)
  {
     this.seeing_place=seeing_place;
  }
  getSeeing_place()
  {
    return this.seeing_place;      
  }
  setYoutubeValue(youtube_value: any) {
    this.youtube_value=youtube_value;
  }
  getYoutubeValue() {
        return this.youtube_value;
  }
  setLength(length: number) {
    // throw new Error("Method not implemented.");
       this.arr_length=length;
  }
  getLength()
  {
    return this.arr_length;
  }
  setEstimatedDays(days: number) {
    // throw new Error("Method not implemented.");
    this.est_days=days;
  }
  getEstimatedDays()
  {
    return this.est_days;
  }
  setUser(firstName:string)
  {
        this.firstName=firstName;
        this.isSigned=true;
        this.change.emit(this.isSigned);
  }
  closingOpened()
  {
    this.open.emit(this.isOpened);
  }
  getUser()
  {
       return this.firstName;
  }
  setMail(email: string) {
        this.email=email;
  }
  getMail()
  {
    return this.email;
  }
  logout() {
       this.isSigned=false;
      //  return this.isSigned;
  }
  
}

