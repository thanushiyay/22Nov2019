const mongoose = require('mongoose');
const Wishlist = require('../models/model.wishlist');
class WishlistService {
    static checkForSaved(body) {
        const update_value =
        {
            date: body.date,
            det: body.det,
            visiting_place: body.visiting_place,
            seeing_type: body.seeing_type
        }
        return new Promise((resolve, reject) => {

            Wishlist.findOne({email:body.email},function(err,result)
            {
                    if(err)  reject(err);
                    if(!result) resolve(0);
                    if(result)
                    {
                        Wishlist.findOneAndUpdate(
                            { email: body.email },
                            { $push: { saved_details: update_value } }, function (err, result) {
                                if (err) reject(err);
                                else {
                                    console.log("result" +result);
                                    resolve(1);
                                }
                            });
                    }
                    
                
                    
            });
        });

    }


    static create(body) {
        const wishlist = new Wishlist({
            email: body.email,
            saved_details: [
                {
                    date: body.date,
                    det: body.det,
                    visiting_place: body.visiting_place,
                    seeing_type: body.seeing_type
                }
            ]
        });

        wishlist.save();
        return 1;
        
    }
}
module.exports = WishlistService;